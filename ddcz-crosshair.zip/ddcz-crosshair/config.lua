Config = {}

Config.DefaultCrosshair = {
    size = 20,
    thickness = 2,
    color = "#ffffff",
    opacity = 100,
    visible = true,
    alwaysVisible = false,
    shape = "cross",
    dynamic = false,
    dynamicMultiplier = 2.0,
    glow = false,
    glowColor = "#00ffff",
    glowSize = 10,
    outlineColor = "#000000",
    outlineThickness = 0
}

Config.Presets = {
    {
        name = "Default",
        settings = {
            size = 20,
            thickness = 2,
            color = "#ffffff",
            shape = "cross"
        }
    },
    {
        name = "Tactical",
        settings = {
            size = 15,
            thickness = 1,
            color = "#00ff00",
            shape = "cross"
        }
    }
}

Config.Keybind = "F5"