let currentData = {};

function updatePreview() {
    const preview = document.getElementById('crosshair-preview');
    preview.innerHTML = '';
    
    if (!currentData.visible) {
        preview.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
        return;
    }

    preview.style.backgroundColor = 'rgba(0, 0, 0, 0.3)';

    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.top = '50%';
    container.style.left = '50%';
    container.style.transform = 'translate(-50%, -50%)';

    // Glow effect
    if (currentData.glow && currentData.glowSize > 0) {
        if (currentData.shape === 'cross') {
            const horizontalGlow = document.createElement('div');
            horizontalGlow.style.position = 'absolute';
            horizontalGlow.style.width = `${currentData.size + currentData.glowSize * 2}px`;
            horizontalGlow.style.height = `${currentData.thickness + currentData.glowSize * 2}px`;
            horizontalGlow.style.backgroundColor = currentData.glowColor;
            horizontalGlow.style.transform = 'translate(-50%, -50%)';
            horizontalGlow.style.opacity = '0.7';
            
            const verticalGlow = document.createElement('div');
            verticalGlow.style.position = 'absolute';
            verticalGlow.style.width = `${currentData.thickness + currentData.glowSize * 2}px`;
            verticalGlow.style.height = `${currentData.size + currentData.glowSize * 2}px`;
            verticalGlow.style.backgroundColor = currentData.glowColor;
            verticalGlow.style.transform = 'translate(-50%, -50%)';
            verticalGlow.style.opacity = '0.7';
            
            container.append(horizontalGlow, verticalGlow);
        } else if (currentData.shape === 'dot') {
            const dotGlow = document.createElement('div');
            dotGlow.style.width = `${currentData.thickness + currentData.glowSize * 2}px`;
            dotGlow.style.height = `${currentData.thickness + currentData.glowSize * 2}px`;
            dotGlow.style.borderRadius = '50%';
            dotGlow.style.backgroundColor = currentData.glowColor;
            dotGlow.style.opacity = '0.7';
            container.appendChild(dotGlow);
        }
    }

    // Outline effect
    if (currentData.outlineThickness > 0) {
        if (currentData.shape === 'cross') {
            const horizontalOutline = document.createElement('div');
            horizontalOutline.style.position = 'absolute';
            horizontalOutline.style.width = `${currentData.size}px`;
            horizontalOutline.style.height = `${currentData.thickness + currentData.outlineThickness * 2}px`;
            horizontalOutline.style.backgroundColor = currentData.outlineColor;
            horizontalOutline.style.transform = 'translate(-50%, -50%)';
            
            const verticalOutline = document.createElement('div');
            verticalOutline.style.position = 'absolute';
            verticalOutline.style.width = `${currentData.thickness + currentData.outlineThickness * 2}px`;
            verticalOutline.style.height = `${currentData.size}px`;
            verticalOutline.style.backgroundColor = currentData.outlineColor;
            verticalOutline.style.transform = 'translate(-50%, -50%)';
            
            container.append(horizontalOutline, verticalOutline);
        } else if (currentData.shape === 'dot') {
            const dotOutline = document.createElement('div');
            dotOutline.style.width = `${currentData.thickness + currentData.outlineThickness * 2}px`;
            dotOutline.style.height = `${currentData.thickness + currentData.outlineThickness * 2}px`;
            dotOutline.style.borderRadius = '50%';
            dotOutline.style.backgroundColor = currentData.outlineColor;
            container.appendChild(dotOutline);
        }
    }

    // Main crosshair
    if (currentData.shape === 'cross') {
        const horizontal = document.createElement('div');
        horizontal.style.position = 'absolute';
        horizontal.style.width = `${currentData.size}px`;
        horizontal.style.height = `${currentData.thickness}px`;
        horizontal.style.backgroundColor = currentData.color;
        horizontal.style.transform = 'translate(-50%, -50%)';
        horizontal.style.opacity = currentData.opacity / 100;
        
        const vertical = document.createElement('div');
        vertical.style.position = 'absolute';
        vertical.style.width = `${currentData.thickness}px`;
        vertical.style.height = `${currentData.size}px`;
        vertical.style.backgroundColor = currentData.color;
        vertical.style.transform = 'translate(-50%, -50%)';
        vertical.style.opacity = currentData.opacity / 100;
        
        container.append(horizontal, vertical);
    } else if (currentData.shape === 'dot') {
        const dot = document.createElement('div');
        dot.style.width = `${currentData.thickness}px`;
        dot.style.height = `${currentData.thickness}px`;
        dot.style.borderRadius = '50%';
        dot.style.backgroundColor = currentData.color;
        dot.style.opacity = currentData.opacity / 100;
        container.appendChild(dot);
    }
    
    preview.appendChild(container);
}

function updateSliderValues() {
    document.getElementById("sizeValue").textContent = currentData.size;
    document.getElementById("thicknessValue").textContent = currentData.thickness;
    document.getElementById("opacityValue").textContent = currentData.opacity;
    document.getElementById("outlineValue").textContent = currentData.outlineThickness;
    document.getElementById("glowValue").textContent = currentData.glowSize;
    document.getElementById("dynamicValue").textContent = currentData.dynamicMultiplier;
}

window.addEventListener('message', (event) => {
    if (event.data.action === 'openMenu') {
        currentData = event.data.crosshair;
        
        // Naplnění formuláře
        document.getElementById('color').value = currentData.color;
        document.getElementById('size').value = currentData.size;
        document.getElementById('thickness').value = currentData.thickness;
        document.getElementById('shape').value = currentData.shape;
        document.getElementById('visible').checked = currentData.visible;
        document.getElementById('alwaysVisible').checked = currentData.alwaysVisible;
        document.getElementById('opacity').value = currentData.opacity;
        document.getElementById('dynamic').checked = currentData.dynamic;
        document.getElementById('dynamicMultiplier').value = currentData.dynamicMultiplier;
        document.getElementById('glow').checked = currentData.glow;
        document.getElementById('glowColor').value = currentData.glowColor;
        document.getElementById('glowSize').value = currentData.glowSize;
        document.getElementById('outlineColor').value = currentData.outlineColor;
        document.getElementById('outlineThickness').value = currentData.outlineThickness;
        
        // Fill presets dropdown
        const presetSelect = document.getElementById('preset');
        presetSelect.innerHTML = '<option value="">LOAD PRESET...</option>';
        event.data.presets.forEach(preset => {
            const option = document.createElement('option');
            option.value = preset.name;
            option.textContent = preset.name;
            presetSelect.appendChild(option);
        });
        
        updateSliderValues();
        updatePreview();
        document.body.style.display = 'flex';
    }
});

// Event listener pro všechny inputy
const inputs = ['color', 'size', 'thickness', 'shape', 'visible', 'alwaysVisible', 'opacity', 
                'dynamic', 'dynamicMultiplier', 'glow', 'glowColor', 'glowSize', 
                'outlineColor', 'outlineThickness'];
inputs.forEach(id => {
    const element = document.getElementById(id);
    if (element) {
        element.addEventListener('input', () => {
            currentData[id] = element.type === 'checkbox' ? element.checked : element.value;
            
            if (element.type === 'range' || element.type === 'number') {
                currentData[id] = parseFloat(currentData[id]);
            }
            
            updatePreview();
            updateSliderValues();
            
            // Odeslání změn na server
            fetch(`https://${GetParentResourceName()}/updateCrosshair`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(currentData)
            });
        });
    }
});

document.getElementById('loadPreset').addEventListener('click', () => {
    const presetSelect = document.getElementById('preset');
    if (presetSelect.value) {
        fetch(`https://${GetParentResourceName()}/loadPreset`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ presetName: presetSelect.value })
        });
    }
});

document.getElementById('save').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    document.body.style.display = 'none';
});

document.getElementById('close').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    document.body.style.display = 'none';
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        fetch(`https://${GetParentResourceName()}/closeMenu`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
        document.body.style.display = 'none';
    }
});