local crosshairData = Config.DefaultCrosshair
local showCrosshair = crosshairData.visible
local uiOpen = false
local baseSize = crosshairData.size
local baseThickness = crosshairData.thickness

local function LoadPreset(presetName)
    for _, preset in ipairs(Config.Presets) do
        if preset.name == presetName then
            for k, v in pairs(preset.settings) do
                crosshairData[k] = v
            end
            showCrosshair = crosshairData.visible
            baseSize = crosshairData.size
            baseThickness = crosshairData.thickness
            if uiOpen then
                SendNUIMessage({
                    action = "updateFields",
                    crosshair = crosshairData
                })
            end
            return true
        end
    end
    print("[Crosshair] Preset '"..presetName.."' not found!")
    return false
end

function HexToRGB(hex)
    hex = hex:gsub("#","")
    return tonumber("0x"..hex:sub(1,2)), tonumber("0x"..hex:sub(3,4)), tonumber("0x"..hex:sub(5,6))
end

RegisterCommand("crosshair", function()
    SetNuiFocus(true, true)
    uiOpen = true
    SendNUIMessage({
        action = "openMenu",
        crosshair = crosshairData,
        presets = Config.Presets
    })
end)

RegisterKeyMapping('crosshair', 'Open Crosshair Menu', 'keyboard', Config.Keybind)

RegisterNUICallback("closeMenu", function(_, cb)
    SetNuiFocus(false, false)
    uiOpen = false
    cb({})
end)

RegisterNUICallback("updateCrosshair", function(data, cb)
    crosshairData = data
    showCrosshair = data.visible
    baseSize = data.size
    baseThickness = data.thickness
    cb({})
end)

RegisterNUICallback("loadPreset", function(data, cb)
    LoadPreset(data.presetName)
    cb({})
end)

-- Hlavní renderovací smyčka
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        
        -- Dynamické rozšíření
        local currentSize = baseSize
        local currentThickness = baseThickness
        
        if crosshairData.dynamic then
            local ped = PlayerPedId()
            local speed = GetEntitySpeed(ped)
            local isShooting = IsPedShooting(ped)
            
            if speed > 1.0 or isShooting then
                currentSize = baseSize * crosshairData.dynamicMultiplier
                currentThickness = baseThickness * crosshairData.dynamicMultiplier
            end
        end
        
        -- Zobrazení crosshair
        local shouldDisplay = crosshairData.visible
        if not crosshairData.alwaysVisible then
            shouldDisplay = shouldDisplay and IsPlayerFreeAiming(PlayerId())
        end

        if shouldDisplay and not uiOpen then
            local screenW, screenH = GetActiveScreenResolution()
            local x, y = 0.5, 0.5
            local r, g, b = HexToRGB(crosshairData.color)
            local a = math.floor(255 * (crosshairData.opacity / 100))
            
            -- Glow effect
            if crosshairData.glow and crosshairData.glowSize > 0 then
                local glowR, glowG, glowB = HexToRGB(crosshairData.glowColor)
                local glowA = math.floor(255 * (crosshairData.opacity / 100 * 0.7)) -- 70% of main opacity
                local glowSize = crosshairData.glowSize
                
                if crosshairData.shape == "cross" then
                    -- Horizontal glow
                    DrawRect(x, y, (currentThickness + glowSize*2)/screenW, (currentSize + glowSize*2)/screenH, glowR, glowG, glowB, glowA)
                    -- Vertical glow
                    DrawRect(x, y, (currentSize + glowSize*2)/screenW, (currentThickness + glowSize*2)/screenH, glowR, glowG, glowB, glowA)
                elseif crosshairData.shape == "dot" then
                    DrawRect(x, y, (currentThickness + glowSize*2)/screenW, (currentThickness + glowSize*2)/screenH, glowR, glowG, glowB, glowA)
                end
            end
            
            -- Outline effect
            if crosshairData.outlineThickness and crosshairData.outlineThickness > 0 then
                local outlineR, outlineG, outlineB = HexToRGB(crosshairData.outlineColor)
                local outlineA = a -- Same opacity as main
                local outlineSize = crosshairData.outlineThickness
                
                if crosshairData.shape == "cross" then
                    -- Horizontal outline
                    DrawRect(x, y, (currentThickness + outlineSize*2)/screenW, currentSize/screenH, outlineR, outlineG, outlineB, outlineA)
                    -- Vertical outline
                    DrawRect(x, y, currentSize/screenW, (currentThickness + outlineSize*2)/screenH, outlineR, outlineG, outlineB, outlineA)
                    -- Main cross (covers center of outline)
                    DrawRect(x, y, currentThickness/screenW, currentSize/screenH, r, g, b, a)
                    DrawRect(x, y, currentSize/screenW, currentThickness/screenH, r, g, b, a)
                elseif crosshairData.shape == "dot" then
                    DrawRect(x, y, (currentThickness + outlineSize*2)/screenW, (currentThickness + outlineSize*2)/screenH, outlineR, outlineG, outlineB, outlineA)
                    DrawRect(x, y, currentThickness/screenW, currentThickness/screenH, r, g, b, a)
                end
            else
                -- Hlavní crosshair (no outline)
                if crosshairData.shape == "cross" then
                    DrawRect(x, y, currentThickness/screenW, currentSize/screenH, r, g, b, a)
                    DrawRect(x, y, currentSize/screenW, currentThickness/screenH, r, g, b, a)
                elseif crosshairData.shape == "dot" then
                    DrawRect(x, y, currentThickness/screenW, currentThickness/screenH, r, g, b, a)
                end
            end
        end
    end
end)