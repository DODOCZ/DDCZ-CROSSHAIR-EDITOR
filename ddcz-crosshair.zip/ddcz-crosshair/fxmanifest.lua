fx_version 'cerulean'
game 'gta5'

name 'Modern Crosshair'
author 'Váš Nick'
version '1.2.0'

ui_page 'html/index.html'

client_scripts {
    'config.lua',
    'client.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/assets/*.png'
}